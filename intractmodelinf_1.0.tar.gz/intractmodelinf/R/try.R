#obsData <- read.csv("data/new_example.csv")

# source("R/RcppExports.R")

#abc(obsData, 10, 2)