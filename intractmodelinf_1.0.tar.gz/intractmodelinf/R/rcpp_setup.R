#' @useDynLib intractmodelinf
#' @importFrom Rcpp sourceCpp
NULL
